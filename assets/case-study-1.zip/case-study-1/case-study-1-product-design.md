# Designing the NFIRA Client Engagement System

**Role:** Product Designer & Systems Owner (sole designer/builder)
**Company:** NFI Solutions
**Timeline:** December 2025 – Present (ongoing)
**Tools:** HubSpot, Microsoft Excel, Microsoft Bookings, Zapier, AI-assisted tools (Claude, ChatGPT/Codex)
**Part of:** NFIRA Client Relationship & Engagement System — one product, three case studies (Product Design / UI/UX / MarTech & Automation)

> Note: All screenshots below use test data ("Sample Client," "Test Contact 2") and internal reference names. Staff last names have been blocked out. Nothing shown reveals real client information.

---

## The Brief

The founder gave me a short, plainly stated goal:

> Build an automation system that can track and send emails and messages for us. It should be intelligent but personal — there should still be a human touch to it. It cannot be entirely automated. It should require a human voice.

That single sentence is the design constraint the rest of this project had to satisfy. It ruled out a fully automated drip campaign on one side, and a fully manual process on the other. Everything I built had to draw a defensible line between what a system could safely decide and what a person had to.

## The Problem

NFIRA runs recurring client seminars (about 12 a year). Every attendee needs to move through registration, attendance, a follow-up appointment, and — depending on how that appointment goes — one of several very different long-term paths. All of this was the responsibility of **one CRE (Client Relationship & Engagement) staff member**, working alone, handling every call, text, email, and appointment reminder herself.

There was no existing system to track where any given client actually was in that process. That absence is the real starting problem: not "we need automation" as an abstract goal, but "one person cannot reliably hold the state of dozens of relationships in her head, and nothing is there to hold it for her."

## v0 — A Manual System, Designed to Buy Time

Before I could build any automation, the CRE needed something to work from immediately. I designed a multi-tab Excel workbook — a client-by-client "quick guide" — as an interim system while the real automation was still being built.

**How it worked:**
- A **CRE Client List** auto-populated from every client's individual tab, so she always had one place to see who was due for contact.
- Each client got their own tab with a **CURRENT row** — the single next unfinished action — and a full path laid out below it (Path 1: attended + booked, Path 1B: no-show recovery, Path 2: attended but didn't book, Path 3: registered but didn't attend).
- Inactive paths grayed out automatically, so she wasn't reading five parallel timelines to find the one that mattered.
- A **path-change log** recorded every time a client moved between paths, with a reason.

I was explicit — on the page itself — about what the workbook could and couldn't do:

| What the workbook does for you | What you still do yourself |
|---|---|
| Shows every client and their current step | Make every call and manually send every text, email, or note |
| Calculates due dates | Choose the client's current path and enter the dates |
| Grays out paths that don't apply | Mark each step's status |
| Flags overdue work | Record STOP/opt-out requests immediately |

That split table is the founder's brief translated directly into an interface. The workbook organizes and tracks; the human still does every act of actual contact. That boundary — not the spreadsheet mechanics — is the design decision.

<p align="center">
  <img src="images/v0-01-start-here.png" width="720" alt="v0 START HERE page showing setup steps and the split between what the workbook automates and what the CRE still does manually" />
</p>

<p align="center">
  <img src="images/v0-03-client-followup-list.png" width="600" alt="CRE Client Follow-Up List, auto-populated from each client's tab" />
</p>

<p align="center">
  <img src="images/v0-04-quick-guide-path1-1b.png" width="720" alt="Per-client quick guide showing the CURRENT row and Path 1 / Path 1B timelines" />
</p>

### Where v0 broke down

The workbook worked as a stopgap, but it had a real failure mode. As her caseload grew, **she was spending more time updating the tracker than actually doing the outreach work it was meant to support.** Logging a status change, writing a note, and moving the CURRENT row forward became its own job on top of the calls and texts she was already making.

Her workaround was to split off onto informal notes she kept separately — which meant the system I'd built to prevent things from falling through the cracks was itself becoming a place things could fall through the cracks, simply because updating it cost more than it saved. That wasn't a small bug; it was a sign the whole approach didn't scale. **It couldn't be fixed within the workbook — it could only be fixed by finishing the real automation.**

There was a second, quieter problem. I'd used one piece of sample data across the workbook (a client who missed an appointment, was moved to recovery, then rescheduled and came back to Path 1) specifically to test whether the layout could represent a *changing* situation clearly. It couldn't, not well. Plain text and static dates didn't visually distinguish "here's what happened three weeks ago" from "here's what's happening now." Even I had to read carefully to tell which path a client was actually on. That direct, hands-on finding is what shaped the state model in the real system: the automation couldn't just log history, it had to make the *current* state impossible to misread.

<p align="center">
  <img src="images/v0-06-quick-checklist-and-path-log.png" width="500" alt="Quick checklist and path-change log showing a client's history of moving between paths" />
</p>

## v1 — A Single Workflow Reaches Its Limit

The first version of the real automation was one HubSpot workflow: a branch on "NFIRA Journey Stage" that updated a couple of status fields per stage. At the time, that felt like enough — it only had to keep a few properties in sync.

<p align="center">
  <img src="images/v1-01-lifecycle-engine-left.png" width="720" alt="Legacy Lifecycle Engine v1, a single branching workflow keyed on NFIRA Journey Stage" />
</p>
<p align="center">
  <img src="images/v1-02-lifecycle-engine-right.png" width="720" alt="Lifecycle Engine v1 continued, showing additional branches for appointment and referral states" />
</p>

It stopped being enough the moment automated emails, texts, and task creation entered the picture. A single branching workflow is fine for "set field A to value B." It is the wrong shape for "figure out whether this contact should be suppressed, decide which of several multi-week cadences they belong in, and hand off to the right one — while never contradicting a suppression that happened five minutes ago." That complexity is what forced the move from one workflow to a proper system: the CRE Automation Engine.

## v2 — The CRE Automation Engine

The core architectural decision was to stop trying to do everything in one place and instead build a **router**. `WF-00 | Master Path Router` doesn't send anything or write cadence content — its only job is to look at a contact's current properties and decide which specialized workflow should own them next.

**Priority order, top to bottom:**
1. **Hard Exit / Suppression** — checked first, unconditionally
2. **Deferred** — re-engagement requests get a holding branch
3. **Path 1 / 1B / 2 / 3** — the seminar-outcome branches, each re-checked against suppression before anything is set

<p align="center">
  <img src="images/wf00-01-trigger-and-branch-overview.png" width="720" alt="WF-00 trigger conditions and top-level branch order" />
</p>
<p align="center">
  <img src="images/wf00-02-hard-exit-and-deferred.png" width="720" alt="Hard Exit/Suppression and Deferred branches in WF-00" />
</p>

### The suppression-priority fix

Early on, the router had a race condition: a contact could be suppressed by `WF-90`, but if `WF-00` re-ran afterward on an unrelated trigger, it could re-evaluate the contact as "Attended" and route them straight back into an active path — silently undoing the suppression. The fix was architectural, not a patch: **every path branch in `WF-00` now checks Suppression/Exit *before* it's allowed to set a cadence path.** Suppression isn't a state the router might notice; it's a gate every other branch has to pass through first. You can see that pattern repeated at every path (1, 2, and 3) in the screenshots below — it's not a one-off check, it's a rule the whole router follows consistently.

<p align="center">
  <img src="images/wf00-04-suppression-check-and-path1.png" width="720" alt="Path 1 branch checking Suppression/Exit before setting Cadence Path to Active" />
</p>

### A returning client isn't a new client

Path 1 has a sub-branch, "Yes/Returning," for a contact whose Cadence Day/Step shows they already went through no-show recovery. Rather than treating them as a fresh Path 1 entry, the router logs a note and hands them specifically to `WF-01 | Path 1 — Appointment Protection` — a different workflow than a first-time booking would get. Recognizing that "booked again after recovering" is not the same situation as "booked for the first time," and routing it differently, was a deliberate call rather than something HubSpot gave me for free.

<p align="center">
  <img src="images/wf00-05-path1-returning-branch.png" width="720" alt="Path 1's Yes/Returning branch logging a note and handing off to WF-01 Appointment Protection" />
</p>

### Two doors into long-term nurture

A contact can reach Long-Term Nurture two ways: naturally, by aging through Path 2's full cadence without converting, or directly, if they've already told us "Declined – Nurture Okay." Both are legitimate paths into the same place, and the router treats them as parallel rather than forcing every contact through the full cadence first.

<p align="center">
  <img src="images/wf00-06-long-term-nurture-and-path3.png" width="720" alt="Branch checking for Declined - Nurture Okay as a direct path into Long-Term Nurture, alongside Path 3 registered-no-show handling" />
</p>

### A small workflow that proves the same rule

`WF-11 | Deferred Re-Engagement` handles clients who asked to be paused and are now due to come back. It's a good example at a smaller scale of a rule that governs the whole system: **workflows set state, only the router decides where a contact goes next.** WF-11 sets Re-Engagement Status, sets Cadence Status back to Active, clears the follow-up request — and then explicitly hands the contact back to `WF-00` rather than routing them anywhere itself.

<p align="center">
  <img src="images/wf11-01-branch-logic.png" width="480" alt="WF-11 branch handling on-assigned-date and after-assigned-date re-engagement" />
</p>
<p align="center">
  <img src="images/wf11-02-handoff-to-wf00.png" width="380" alt="WF-11 clearing the follow-up request and handing the contact back to WF-00" />
</p>

## The Scope Decision

Once the router and paths were working, I made a deliberate call about how far to take the automation:

> **CRE v1 automates through the first appointment. After that, the relationship becomes primarily human-led.**

This is a direct continuation of the founder's original constraint. Automation is reliable at getting someone to a first appointment: reminders, confirmations, recovery from a no-show. Past that point, the conversation is about someone's actual financial situation, and that's exactly the kind of interaction the founder said needed a human voice. I designed the system's boundary to match that judgment, rather than automating everything simply because it was technically possible to.

## Where This Stands

The CRE Automation Engine is live but new — there isn't outcome data yet, and I'm not going to publish a made-up number. What I can say concretely: it replaces the workbook's core failure — the CRE having to manually track and update where every client stood — with a system that tracks it for her and tells her only what to do next. What I'd want to measure once there's enough data: how much of her previous manual tracking work (not outreach — tracking) has actually disappeared, and whether contacts are moving through paths on schedule versus getting deferred.

## What I'd Do Differently

- I'd design the v0 workbook's state display (path + log) to make a *changing* situation visually obvious from the start, instead of discovering that failure through use.
- I'd instrument the automation for basic timing metrics (time-to-suppression-check, time in each cadence step) from day one, so "did this actually save her time" has real numbers behind it instead of an estimate.
